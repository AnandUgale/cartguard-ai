# CartGuard AI

A local prototype combining genuine CPU semantic product ranking, deterministic purchasing limits and a verified PayPal sandbox checkout. All 30 merchant products, prices and stock are fictional. No real goods are sold or fulfilled.

**Current evidence:** real MiniLM inference and genuine sandbox OAuth, create, guest approval, capture and strict full-order verification executed through ChatGPT internal browser. USD 69.00 order `2MA31808Y5978251A` / capture `9N875108U25554533` became PAID and survived page reload plus actual server restart. 47 automated tests pass; payment failure/crash/concurrency tests remain fixtures. Checkout stays disabled without credentials; an existing verified receipt remains readable. This is not a submitted competition entry. See [judge quickstart](JUDGE-QUICKSTART.md) and [sanitized verification evidence](evidence/sandbox-checkout-verification-2026-10-25.md).

## Run locally

Requires Node.js 24+ (tested 24.18.0) and npm. From this directory:

```powershell
npm ci --no-fund --no-audit
npm test
npm run evaluate
npm start
```

Open http://127.0.0.1:8765 in ChatGPT's internal browser. The server binds only to loopback and accepts the exact `127.0.0.1` origin; `localhost`, reverse proxies and external hosting are not configured.

The four pinned MiniLM model/config/tokenizer assets are bundled in `models/minilm/`, with Apache-2.0 license, attribution and SHA-256 manifest. Initialization verifies hashes, uses CPU and local_files_only, and disables remote model access. No prompt or model request is sent to an AI provider. Transformers.js 4.3.1 is locked; `Xenova/all-MiniLM-L6-v2` q8 is pinned to revision `751bff37182d3f1213fa05d7196b954e230abad9`. Original no-card model downloads succeeded on October 25, but a later clean-build fetch failed. Bundling removes that runtime dependency. Installing npm packages and actual PayPal sandbox operations still need normal network access.

An install policy may leave dependency install scripts pending. Inspect npm's output rather than disabling security controls. The tested installation loaded ONNX Runtime successfully without a global runtime change.

## Use the prototype

1. Describe a need, confirm maximum total and quantity, then run **Local AI · MiniLM**. It computes real 384-dimensional embeddings and cosine rankings; no heuristic is presented as AI.
2. Compare **Keyword baseline · TF-IDF**, which explicitly performs no AI inference. Both modes apply identical stock and budget filters.
3. Review the product's actual fictional attributes. Relative ranking is not a suitability probability; the app does not abstain on unsupported semantic intent. An irrelevant query can still return within-budget products.
4. Select a product to lock a ten-minute server quote. The browser cannot supply price/currency. Stock reservations, quote totals and identities are persisted in SQLite.
5. Without sandbox credentials, inspect and release the quote. There is no mock payment button or hidden fixture provider in the running server.

## PayPal sandbox gate

The existing account accesses the Sandbox dashboard and Default Application without a live upgrade/card linkage in the observed path. **OAuth, creation, guest approval, capture and strict completed-order verification succeeded.** The human explicitly approved memory-only sandbox credential use. No new app/account was created. The successful hosted guest flow used PayPal-generated synthetic test-card data and fictional buyer data, with account creation OFF. Passwords/OTPs, account agreements and applicable final actions remain with the human. Never paste credentials into chat, source, research, screenshots or logs.

Preferred in-app setup: open `http://127.0.0.1:8765/sandbox-setup`. After specific authorization, enter the existing Sandbox app client ID and secret. The local server verifies OAuth, keeps credentials only in memory, clears the form, and binds payment actions to that browser session. It does not create a new app/key/order. Restarting removes this connection. Failed OAuth does not activate the adapter; credentials cannot be replaced through the form while it is configured.

For separately authorized manual environment setup, `.env.example` documents the alternative `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET` variables; no `.env` has been created by the agent. Never use live credentials. The adapter's host is fixed to `https://api-m.sandbox.paypal.com`; a production host cannot be selected with an environment variable. Client secrets and OAuth tokens stay server-side. Never publish `.env`, `data/` or model cache. `/api/sandbox/evidence` returns sanitized endpoint/status/timestamp metadata, never request headers, bodies or credentials.

The integration flow (one complete genuine sandbox run verified):

- Explicitly approve the exact quote, create a sandbox order, and open its validated sandbox approval URL.
- Approve using a sandbox buyer account (human enters password) or the offered hosted guest flow with official synthetic sandbox test-card data and account creation OFF. A return is **not** proof of payment. Never enter a real card or actual person's private details.
- Request capture of that bound order. The server then reads the full order and requires its ID, CAPTURE intent, quote references, amount/currency, and single final completed capture to match before recording `PAID`.
- Network ambiguity remains unresolved. Use the read-only payment-state check rather than starting another purchase. No real fulfillment occurs in any state.

Verified actual evidence: OAuth; real-AI-to-create/approve/capture; a read-only APPROVED check; full bound-order COMPLETED verification; durable receipt after restart; safe local expiry disposition after an uncaptured-order read. Provider cancellation and lost-reply/concurrent-capture behavior remain unverified with actual PayPal; those tests are labelled fixtures. No provider cancellation is implied by closing a local quote. The first guest return exposed a SameSite=Strict session bug; Lax now preserves top-level return GETs, with exact Origin and HMAC-CSRF still required for all mutations.

## Payment consistency

SQLite stores immutable quote terms, separate create/capture request UUIDs, operation state, unique provider order/capture identities and reconciliation time. Quote outcome and operation identities commit together. Database claims serialize operations across service instances; an in-memory queue also handles local concurrent requests. A claim has a 90-second recovery lease, exceeding the normal bounded API request chain. After an abrupt process exit, allow the dead claim to expire before retrying.

The request key is committed before the network call. Unknown capture outcomes are read before retrying the same operation. Read-only recovery works after quote expiry; a fresh capture does not. Unresolved operations retain their stock reservation. This is a tested local recovery design, not a claim of universal exactly-once payment behavior or verified PayPal idempotency retention.

Tests cover a child process exiting immediately after a **simulated** provider captures, followed by database reopen, competing service instances, a transient status-read failure, and recovery to the same recorded capture without another simulated capture. No network is involved in this test.

## Evaluation and limitations

`npm run evaluate` executes the real model and writes `evidence/ai-evaluation-v2.json`, including model-file SHA-256 hashes, runtime, labels, outputs and latency. The 36-query set is frozen, synthetic and agent-authored: 32 relevance queries and four no-eligible cases. On both preserved runs, top-1 was 30/32 for MiniLM and 16/32 for TF-IDF; nDCG@5 was 0.9707 versus 0.6770. Both had zero tested constraint violations. In v2, warm median query latency was 3 ms for MiniLM versus a rounded 0 ms for TF-IDF on this machine. These are engineering measurements, not independent benchmark results or real-user feedback. V1 used Transformers.js 3.8.1; it was replaced after npm audit reported transitive sharp advisories. V2 uses 4.3.1 and npm audit reported zero known vulnerabilities at the check time. The versioned 4.3.1 online Node tutorial returned 404; successful installed-package execution is preserved instead of claiming that page verified compatibility.

Preserved disagreements: a folding keyboard request ranked a sling first; a two-caller request labelled headset ranked a desktop microphone. The second label is arguably ambiguous. No label or catalog was tuned after seeing results. Rankings cannot establish product compatibility, safety, stock freshness at real retailers, reduced fraud, conversion improvement or commercial novelty.

The app is a local demonstration with ephemeral browser sessions, no merchant account system, no production authentication, no refunds/webhooks, no shipping/tax calculation and no real inventory. The displayed total is the complete simulated amount. New product breadth, third-party discovery and public hosting are outside this slice.

## Provenance and licensing

Created in this isolated event folder on October 25, 2026, after initial Pro Deep Research and corrected ordinary Pro scope review. The user delegated routine decisions; the human did not personally author or review every plan, test label or code change. No code was copied from another competition. After the final supplemental Pro response failed to load, the agent performed the official-source review and packaging under the user's conditional fallback authorization. That review is agent-led, not Pro-reviewed. Public source omits private research conversations and account information.

Application code: MIT; see `LICENSE`. Third-party dependencies/model retain their own licenses; see `THIRD-PARTY-NOTICES.md`. Repository publication, YouTube footage, eligibility/conflict review, registration, submission and official award verification remain outstanding.


