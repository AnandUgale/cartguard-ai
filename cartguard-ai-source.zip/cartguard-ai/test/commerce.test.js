import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Commerce } from '../src/commerce.js';
import { PayPalSandbox, PaymentError, verifyCapture, SANDBOX } from '../src/paypal.js';
import { constraints, dollars, products, rejection } from '../src/catalog.js';

// FIXTURES ONLY: these responses never call PayPal and are not payment evidence.
function complete(q) {
  return { id: q.orderId, status: 'COMPLETED', intent: 'CAPTURE', purchase_units: [{
    reference_id: q.id, custom_id: q.id, amount: { value: dollars(q.totalCents), currency_code: 'USD' },
    payments: { captures: [{ id: 'FIXTURECAPTURE', status: 'COMPLETED', final_capture: true, amount: { value: dollars(q.totalCents), currency_code: 'USD' } }] }
  }] };
}
function fixture() {
  return {
    enabled: true, mode: 'fixture-only', creates: 0, captures: 0, reads: 0, paid: false,
    async create(q) { this.creates++; this.key = q.createRequestId; return { id: 'FIXTUREORDER', status: 'CREATED', links: [{ rel: 'payer-action', href: 'https://www.sandbox.paypal.com/checkoutnow?token=FIXTUREORDER' }] }; },
    async capture(q) { this.captures++; this.captureKey = q.captureRequestId; this.paid = true; return { id: q.orderId, status: 'COMPLETED' }; },
    async get(q) { this.reads++; return this.paid ? complete(q) : { id: q.orderId, status: 'APPROVED' }; }
  };
}
const body = { productId: 'call-comfort', quantity: 1, budgetCents: 8000 };
function setup(t, overrides = {}) {
  const payment = fixture(); const commerce = new Commerce({ payment, ...overrides }); t.after(() => commerce.close());
  const quote = commerce.quote('owner', body); return { payment, commerce, quote };
}
const created = async (c, q) => c.create(q.id, 'owner', true);

test('constraints: exact-cent boundary, quantity and budget types', () => {
  const p = products[0]; assert.deepEqual(rejection(p, 6900, 1), []); assert.deepEqual(rejection(p, 6899, 1), ['Total exceeds budget']);
  for (const qty of [0,-1,1.5,'1',21]) assert.throws(() => constraints(8000, qty));
  for (const budget of [0,-1,1.1,'8000',Infinity,Number.MAX_SAFE_INTEGER]) assert.throws(() => constraints(budget,1));
});
test('client price/currency tampering is rejected', t => { const {commerce} = setup(t); assert.throws(() => commerce.quote('owner', {...body, totalCents: 1}), /UNEXPECTED/); assert.throws(() => commerce.quote('owner',{...body,currency:'EUR'})); });
test('quote stores server amount, version, expiry and hides owner/request IDs', t => { const {quote}=setup(t); assert.equal(quote.totalCents,6900); assert.equal(quote.expiresAt-quote.createdAt,600000); assert.equal(quote.owner,undefined); assert.equal(quote.createRequestId,undefined); assert.equal(quote.synthetic,true); });
test('quote session ownership enforced', t => {const {commerce,quote}=setup(t); assert.throws(()=>commerce.read(quote.id,'other'),/QUOTE_NOT_FOUND/);});
test('out of stock and insufficient total cannot be quoted',t=>{const {commerce}=setup(t); assert.throws(()=>commerce.quote('owner',{...body,productId:'open-ear'}),/INELIGIBLE/); assert.throws(()=>commerce.quote('owner',{...body,budgetCents:6800}),/INELIGIBLE/);});
test('reservations stop aggregate overselling',t=>{const {commerce}=setup(t); commerce.quote('owner',{productId:'drawing-pad',quantity:4,budgetCents:40000}); assert.throws(()=>commerce.quote('other',{productId:'drawing-pad',quantity:1,budgetCents:8000}),/STOCK_CHANGED/);});
test('explicit approval required before create',async t=>{const {commerce,quote,payment}=setup(t); await assert.rejects(commerce.create(quote.id,'owner',false),/APPROVAL/); assert.equal(payment.creates,0);});
test('missing credentials fail closed without changing quote',async t=>{const {commerce,quote,payment}=setup(t); payment.enabled=false; await assert.rejects(created(commerce,quote),/NOT_CONFIGURED/); assert.equal(commerce.read(quote.id,'owner').state,'QUOTED');});
test('create retry and concurrent requests reuse one logical order',async t=>{const {commerce,quote,payment}=setup(t); const results=await Promise.all([created(commerce,quote),created(commerce,quote),created(commerce,quote)]); assert.equal(payment.creates,1); assert.ok(results.every(r=>r.orderId==='FIXTUREORDER'));});
test('unknown create retries with persisted same request ID',async t=>{const {commerce,quote,payment}=setup(t); const original=payment.create.bind(payment); let first=true; payment.create=async q=>{if(first){first=false;payment.firstKey=q.createRequestId;throw new PaymentError('TIMEOUT',true);}return original(q);}; assert.equal((await created(commerce,quote)).state,'CREATE_UNKNOWN'); assert.equal((await created(commerce,quote)).state,'CREATED'); assert.equal(payment.firstKey,payment.key);});
test('production or unrelated approval URL is rejected',async t=>{const {commerce,quote,payment}=setup(t);payment.create=async()=>({id:'FIXTUREORDER',links:[{rel:'approve',href:'https://www.paypal.com/checkoutnow'}]});assert.equal((await created(commerce,quote)).state,'CREATE_UNKNOWN');});
test('expired quote blocks create and capture',async t=>{let now=1000;const {commerce,quote,payment}=setup(t,{now:()=>now});await created(commerce,quote);now+=600001;await assert.rejects(commerce.capture(quote.id,'owner','FIXTUREORDER'),/EXPIRED/);assert.equal(payment.captures,0);const fresh=commerce.quote('owner',body);now+=600001;await assert.rejects(created(commerce,fresh),/EXPIRED/);});
test('wrong order ID cannot trigger capture',async t=>{const {commerce,quote,payment}=setup(t);await created(commerce,quote);await assert.rejects(commerce.capture(quote.id,'owner','UNRELATED'),/MISMATCH/);assert.equal(payment.captures,0);});
test('fixture capture requires full matching order and is idempotent concurrently',async t=>{const {commerce,quote,payment}=setup(t);await created(commerce,quote);const results=await Promise.all(Array.from({length:5},()=>commerce.capture(quote.id,'owner','FIXTUREORDER')));assert.equal(payment.captures,1);assert.ok(results.every(r=>r.state==='PAID'&&r.paymentMode==='fixture-only'));assert.equal(payment.reads,1);});
for(const field of ['amount','currency','reference','custom','order','final','status','intent','multiple']) test(`fixture capture verification rejects ${field} mismatch`,()=>{
  const q={id:'Q',orderId:'ORDER',currency:'USD',totalCents:6900};const order=complete(q);const u=order.purchase_units[0],capture=u.payments.captures[0];
  if(field==='amount')capture.amount.value='1.00';if(field==='currency')capture.amount.currency_code='EUR';if(field==='reference')u.reference_id='OTHER';if(field==='custom')u.custom_id='OTHER';if(field==='order')order.id='OTHER';if(field==='final')capture.final_capture=false;if(field==='status')capture.status='PENDING';if(field==='intent')order.intent='AUTHORIZE';if(field==='multiple')u.payments.captures.push({...capture});assert.equal(verifyCapture(order,q),false);
});
test('mismatch transitions to review, never paid',async t=>{const {commerce,quote,payment}=setup(t);await created(commerce,quote);payment.get=async q=>{const r=complete(q);r.purchase_units[0].payments.captures[0].amount.value='0.01';return r;};const result=await commerce.capture(quote.id,'owner','FIXTUREORDER');assert.equal(result.state,'REVIEW');assert.equal(result.captureId,null);});
test('lost capture reply remains unknown then recovers read-only, even after expiry',async t=>{let now=1000;const {commerce,quote,payment}=setup(t,{now:()=>now});await created(commerce,quote);payment.capture=async()=>{payment.captures++;payment.paid=true;throw new PaymentError('TIMEOUT',true);};assert.equal((await commerce.capture(quote.id,'owner','FIXTUREORDER')).state,'CAPTURE_UNKNOWN');now+=600001;assert.equal((await commerce.reconcile(quote.id,'owner')).state,'PAID');assert.equal(payment.captures,1);});
test('unknown capture retry reconciles before sending a second capture',async t=>{const {commerce,quote,payment}=setup(t);await created(commerce,quote);payment.capture=async()=>{payment.captures++;payment.paid=true;throw new PaymentError('HTTP_500',true);};await commerce.capture(quote.id,'owner','FIXTUREORDER');assert.equal((await commerce.capture(quote.id,'owner','FIXTUREORDER')).state,'PAID');assert.equal(payment.captures,1);});
test('cancel local quote releases reservation and makes no API call',async t=>{const {commerce,quote,payment}=setup(t);assert.equal((await commerce.cancel(quote.id,'owner')).state,'CANCELLED');assert.equal(payment.creates+payment.captures,0);await assert.rejects(created(commerce,quote),/INVALID_STATE/);});
test('created order cancellation demands reconciliation',async t=>{const {commerce,quote}=setup(t);await created(commerce,quote);await assert.rejects(commerce.cancel(quote.id,'owner'),/RECONCILE/);});
test('quote and idempotency survive database reopen',async()=>{
  const base=fileURLToPath(new URL('../data/test-fixtures/',import.meta.url));mkdirSync(base,{recursive:true});
  const dir=mkdtempSync(join(base,'cartguard-'));const path=join(dir,'test.sqlite');const payment=fixture();let c=new Commerce({path,payment});
  try{const q=c.quote('owner',body);payment.create=async quote=>{payment.key=quote.createRequestId;throw new Error('lost reply');};await created(c,q);c.close();c=new Commerce({path,payment});assert.equal(c.read(q.id,'owner').createRequestId,payment.key);assert.equal(c.read(q.id,'owner').state,'CREATE_UNKNOWN');}finally{c.close();rmSync(dir,{recursive:true});}
});
test('sandbox adapter URLs and server-only OAuth/request IDs (fixture HTTP)',async()=>{
  const calls=[];const adapter=new PayPalSandbox({clientId:'fixture-client',clientSecret:'fixture-secret',fetchImpl:async(url,options)=>{calls.push({url,options});return{ok:true,json:async()=>url.endsWith('/token')?{access_token:'fixture-token',expires_in:3600}:{id:'FIXTUREORDER'}};}});
  const q={id:'q',totalCents:6900,createRequestId:'create-key',captureRequestId:'capture-key',orderId:'FIXTUREORDER'};await adapter.create(q);await adapter.capture(q);await adapter.get(q);
  assert.ok(calls.every(c=>c.url.startsWith(SANDBOX+'/')));assert.equal(calls[1].options.headers['PayPal-Request-Id'],'create-key');assert.equal(calls[2].options.headers['PayPal-Request-Id'],'capture-key');assert.equal(JSON.parse(calls[1].options.body).purchase_units[0].amount.value,'69.00');assert.equal(calls[3].options.method,'GET');
});
for(const code of [401,422,429,500])test(`fixture HTTP ${code} is sanitized and cannot confirm capture`,async()=>{const adapter=new PayPalSandbox({clientId:'fixture',clientSecret:'fixture',fetchImpl:async url=>url.endsWith('/token')?{ok:true,json:async()=>({access_token:'secret',expires_in:60})}:{ok:false,status:code}});await assert.rejects(adapter.get({orderId:'ORDER'}),new RegExp(`SANDBOX_HTTP_${code}`));});
