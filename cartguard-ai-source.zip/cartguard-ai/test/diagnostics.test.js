import test from 'node:test';
import assert from 'node:assert/strict';
import { PayPalSandbox } from '../src/paypal.js';
test('sandbox errors retain only a validated issue code, not response data',async()=>{
  const payment=new PayPalSandbox({clientId:'fixture',clientSecret:'fixture',fetchImpl:async url=>url.endsWith('/token')?{ok:true,status:200,json:async()=>({access_token:'fixture-token',expires_in:60})}:{ok:false,status:422,json:async()=>({name:'UNPROCESSABLE_ENTITY',details:[{issue:'ORDER_NOT_APPROVED',description:'private fixture description',payer:'private fixture payer'}]})}});
  await assert.rejects(payment.get({orderId:'ORDER'}),/SANDBOX_ORDER_NOT_APPROVED/);
  assert.equal(payment.events.at(-1).issue,'ORDER_NOT_APPROVED');
  assert.ok(!JSON.stringify(payment.events).includes('private fixture'));
  assert.ok(!JSON.stringify(payment.events).includes('fixture-token'));
});
test('arbitrary issue strings are not preserved in diagnostics',async()=>{
  const payment=new PayPalSandbox({clientId:'fixture',clientSecret:'fixture',fetchImpl:async url=>url.endsWith('/token')?{ok:true,status:200,json:async()=>({access_token:'token'})}:{ok:false,status:422,json:async()=>({details:[{issue:'private fixture content@example.com'}]})}});
  await assert.rejects(payment.get({orderId:'ORDER'}),/SANDBOX_HTTP_422/);
  assert.equal(payment.events.at(-1).issue,undefined);
});
test('actual order-status diagnostics whitelist status without payer details',async()=>{
  const payment=new PayPalSandbox({clientId:'fixture',clientSecret:'fixture',fetchImpl:async url=>url.endsWith('/token')?{ok:true,status:200,json:async()=>({access_token:'token'})}:{ok:true,status:200,json:async()=>({status:'APPROVED',payer:{email_address:'private-fixture@example.com'}})}});
  await payment.get({orderId:'ORDER'});assert.equal(payment.events.at(-1).orderStatus,'APPROVED');assert.ok(!JSON.stringify(payment.events).includes('email'));
});
