import test from 'node:test';
import assert from 'node:assert/strict';
import { connectSandbox } from '../src/sandbox-connection.js';
test('memory-only connection verifies OAuth before activating adapter; response excludes credentials',async()=>{
  const payment={enabled:false};let called=0;const body={clientId:'fixture-client-123456',clientSecret:'fixture-secret-123456'};
  const response=await connectSandbox(payment,body,'http://127.0.0.1:8765',options=>({...options,enabled:true,async token(){called++;return 'fixture-access-token';}}));
  assert.equal(called,1);assert.equal(payment.enabled,true);assert.equal(response.storage,'server-memory-only');assert.equal(response.orderCaptureVerified,false);
  assert.ok(!JSON.stringify(response).includes(body.clientSecret));assert.ok(!JSON.stringify(response).includes(body.clientId));
});
test('failed OAuth does not install supplied credentials',async()=>{
  const payment={enabled:false};await assert.rejects(connectSandbox(payment,{clientId:'fixture-client-123456',clientSecret:'fixture-secret-123456'},'local',()=>({async token(){throw new Error('SANDBOX_AUTH_FAILED');}})),/AUTH_FAILED/);
  assert.equal(payment.enabled,false);assert.equal(payment.clientSecret,undefined);
});
test('existing connection and extra/invalid fields are rejected before OAuth',async()=>{
  await assert.rejects(connectSandbox({enabled:true},{},'local'),/ALREADY_CONFIGURED/);
  await assert.rejects(connectSandbox({enabled:false},{clientId:'x',clientSecret:'y'},'local'),/INVALID/);
  await assert.rejects(connectSandbox({enabled:false},{clientId:'fixture-client-123456',clientSecret:'fixture-secret-123456',live:true},'local'),/UNEXPECTED/);
});
