// Stateful provider FIXTURE used only by PAY-CRASH-01. No network or real PayPal.
import { writeFileSync } from 'node:fs';
import { Commerce } from '../src/commerce.js';
const [db, providerFile] = process.argv.slice(2);
const payment = {
  enabled: true, mode: 'fixture-only',
  async create() { return {id:'CRASHORDER',links:[{rel:'approve',href:'https://www.sandbox.paypal.com/checkoutnow?token=CRASHORDER'}]}; },
  async capture(q) {
    writeFileSync(providerFile, JSON.stringify({ orderId:q.orderId,quoteId:q.id,captureId:'CRASHCAPTURE',logicalOrders:1,completedCaptures:1,requestId:q.captureRequestId,totalCents:q.totalCents }));
    // External side effect persisted; no local completion record is written.
    process.exit(73);
  }
};
const commerce = new Commerce({path:db,payment});
const quote=commerce.quote('crash-owner',{productId:'call-comfort',quantity:1,budgetCents:8000});
await commerce.create(quote.id,'crash-owner',true);
await commerce.capture(quote.id,'crash-owner','CRASHORDER');
