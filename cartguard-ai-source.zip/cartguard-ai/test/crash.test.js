import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Commerce } from '../src/commerce.js';

test('PAY-CRASH-01: process exits after fixture side effect; concurrent restarted clients reconcile one capture', async () => {
  const base=fileURLToPath(new URL('../data/test-fixtures/',import.meta.url));mkdirSync(base,{recursive:true});
  const dir=mkdtempSync(join(base,'cartguard-crash-'));
  const path=join(dir,'test.sqlite'), providerFile=join(dir,'provider.json');
  let a,b;
  try {
    const worker=spawnSync(process.execPath,[fileURLToPath(new URL('./crash-worker.js',import.meta.url)),path,providerFile],{timeout:15000});
    assert.equal(worker.status,73);
    const ledger=JSON.parse(readFileSync(providerFile,'utf8'));
    let reads=0, extraCaptures=0;
    const provider={enabled:true,mode:'fixture-only',async capture(){extraCaptures++;throw new Error('must not recapture');},async get(q){
      reads++;
      if(reads===1) throw new Error('transient fixture status outage');
      return {id:ledger.orderId,intent:'CAPTURE',status:'COMPLETED',purchase_units:[{reference_id:ledger.quoteId,custom_id:ledger.quoteId,amount:{value:'69.00',currency_code:'USD'},payments:{captures:[{id:ledger.captureId,status:'COMPLETED',final_capture:true,amount:{value:'69.00',currency_code:'USD'}}]}}]};
    }};
    // A dead process's lease must expire before another process claims it.
    const now=()=>Date.now()+91000;
    a=new Commerce({path,payment:provider,now});b=new Commerce({path,payment:provider,now});
    const q=a.read(ledger.quoteId,'crash-owner');
    assert.equal(q.state,'CAPTURING');
    assert.equal(q.captureRequestId,ledger.requestId);
    assert.equal(a.db.prepare("SELECT state FROM payment_ops WHERE quote_id=? AND kind='capture'").get(q.id).state,'CAPTURING');
    // Separate service instances share no in-memory mutex. SQLite serializes them.
    const first=await Promise.allSettled([a.capture(q.id,'crash-owner',q.orderId),b.capture(q.id,'crash-owner',q.orderId)]);
    assert.ok(first.some(r=>r.status==='rejected'&&r.reason.code==='PAYMENT_OPERATION_IN_PROGRESS'));
    assert.equal(a.read(q.id,'crash-owner').state,'CAPTURING');
    assert.throws(()=>b.quote('other',{productId:'call-comfort',quantity:8,budgetCents:100000}),/STOCK_CHANGED/);
    const recovered=await b.reconcile(q.id,'crash-owner');
    assert.equal(recovered.state,'PAID');
    assert.equal((await a.capture(q.id,'crash-owner',q.orderId)).state,'PAID');
    assert.equal(extraCaptures,0);
    assert.equal(ledger.logicalOrders,1);assert.equal(ledger.completedCaptures,1);
    const ops=a.db.prepare('SELECT * FROM payment_ops WHERE quote_id=?').all(q.id);
    assert.equal(ops.length,2);assert.equal(ops.find(op=>op.kind==='capture').capture_id,'CRASHCAPTURE');
    assert.equal(a.read(q.id,'crash-owner').captureRequestId,ledger.requestId);
  } finally {a?.close();b?.close();rmSync(dir,{recursive:true});}
});

test('database unique capture identity rejects reuse on another quote',()=>{
  const c=new Commerce({payment:{mode:'fixture-only'}});
  try {
    const one=c.quote('a',{productId:'call-comfort',quantity:1,budgetCents:8000});
    const two=c.quote('b',{productId:'call-comfort',quantity:1,budgetCents:8000});
    c.db.prepare("UPDATE payment_ops SET capture_id='SAMECAPTURE' WHERE quote_id=? AND kind='capture'").run(one.id);
    assert.throws(()=>c.db.prepare("UPDATE payment_ops SET capture_id='SAMECAPTURE' WHERE quote_id=? AND kind='capture'").run(two.id),/UNIQUE/);
  } finally {c.close();}
});
