# Actual sandbox checkout verification

Completed October 25, 2026 entirely in ChatGPT internal browser. Out-of-pocket cost: INR 0. No real funds or goods.

- Real MiniLM selected one fictional CallComfort H2, USD 69.00 against USD 80.00 maximum. Observed search execution: 514 ms after restart.
- Quote `35eff98d-83f0-4a3d-b912-f91efc6018dc`: created 10:45:20.158 UTC, expiry 10:55:20.158 UTC. Capture completed before expiry.
- Order `2MA31808Y5978251A`; capture `9N875108U25554533`.
- OAuth 200 → create 200 → hosted guest approval → GET APPROVED 200 → capture 201 → full GET COMPLETED 200.
- Strict verifier passed bound ID, intent, reference, amount/currency and single-final-completed-capture conditions. Ledger became PAID.
- Receipt persisted through page reload and actual server restart. Restart cleared memory-only credentials/tokens without sending another capture. Saved API sequence contains one POST capture for this order.
- Sanitized evidence omits credentials, session IDs, request keys, payer details and raw provider responses.

Guest checkout used PayPal's official generated synthetic test card, fictional name/address/email and reserved fictional telephone, with account creation OFF. No password, OTP, real card or actual person's private details were used. [Official PayPal testing documentation](https://developer.paypal.com/credit-card-number-generator) was saved separately without generated fields.

The first guest return found a SameSite cookie defect; the app rejected capture before sending it. SameSite=Lax with existing Origin/HMAC-CSRF checks fixed normal return continuity, confirmed by the fresh flow. Earlier orders remain preserved; no provider cancellation is claimed. Earlier failed/expired records remain in the private event ledger; they are not included as successful payments here.

47 automated tests pass; failure/crash/concurrency cases remain fixtures. This run does not establish production behavior, provider idempotency retention, live refunds/cancellation, real customer benefit or competition readiness. Final screenshot: sandbox-durable-receipt-2026-10-25.png.

