# Bundled MiniLM model assets

These four unmodified model/config/tokenizer files are third-party Apache-2.0 assets, not MIT application code. See APACHE-2.0.txt and model-manifest.json.

- Base model: [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2), Sentence Transformers contributors.
- ONNX conversion/quantization: [Xenova/all-MiniLM-L6-v2](https://huggingface.co/Xenova/all-MiniLM-L6-v2), Xenova.
- Exact upstream revision: `751bff37182d3f1213fa05d7196b954e230abad9`.
- Files: config.json, tokenizer.json, tokenizer_config.json, onnx/model_quantized.onnx.
- Retrieved and executed October 25, 2026. SHA-256 hashes are in model-manifest.json and are checked before model initialization.
- Changes: no changes to the four file contents; relocated into this repository for reliable local execution. Model identity, pooling and normalization are unchanged.

The upstream model page declared Apache-2.0, and its observed root file listing contained no separate LICENSE or NOTICE file. The standard Apache 2.0 license is reproduced here. Original model/ONNX-conversion attribution is retained above. Read the linked model cards for training provenance and limitations. CartGuard's relevance labels and product catalog are synthetic; this model does not prove product compatibility or real-user suitability.

Bundling resolves an observed clean-build model-download fetch failure. Model initialization now uses local_files_only and disables remote model access. Installing npm dependencies still requires their normal network access; actual PayPal sandbox calls require internet and the tester's own authorized sandbox credentials.
