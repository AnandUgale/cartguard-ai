const $ = selector => document.querySelector(selector);
const money = cents => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
let config, currentQuote, searching = false;
async function api(path, body) {
  const response = await fetch(path, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': config.csrf }, body: JSON.stringify(body) });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error ?? 'Request failed');
  return result;
}
function element(tag, text, className) { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; }
function status(text, error = false) { $('#search-status').textContent = text; $('#search-status').classList.toggle('error', error); }
function limits() {
  const raw = $('#budget').value;
  if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) throw new Error('Enter a dollar amount with up to two decimals.');
  const [dollars, fraction = ''] = raw.split('.');
  return { budgetCents: Number(dollars) * 100 + Number(fraction.padEnd(2, '0')), quantity: Number($('#quantity').value) };
}
function renderSearch(result, requestedLimits) {
  const container = $('#results'); container.replaceChildren();
  $('#result-count').textContent = `${result.eligible.length} within limits · showing ${Math.min(6,result.eligible.length)}`;
  for (const product of result.eligible.slice(0, 6)) {
    const card = element('article', undefined, 'card');
    card.append(element('div', product.icon, 'icon'), element('h3', product.name), element('p', product.description));
    const price = element('div', undefined, 'price-row'); price.append(element('span', money(product.totalCents), 'price'), element('span', '✓ Within limits', 'tag')); card.append(price);
    card.append(element('div', `Relative relevance ${product.score.toFixed(3)} · fictional product`, 'score'));
    const select = element('button', 'Review locked quote →', 'select');
    select.addEventListener('click', async () => {
      select.disabled = true;
      try {
        if (currentQuote && !['PAID','CANCELLED','EXPIRED_UNCAPTURED'].includes(currentQuote.state)) {
          if (currentQuote.state === 'QUOTED') await api(`/api/quotes/${currentQuote.id}/cancel`, {});
          else throw new Error('Resolve the current sandbox checkout before selecting another option.');
        }
        currentQuote = await api('/api/quotes', { productId: product.id, ...requestedLimits });
        localStorage.setItem('cartguardQuote', currentQuote.id); renderQuote();
      } catch (error) { status(error.message, true); } finally { select.disabled = false; }
    }); card.append(select); container.append(card);
  }
  if (!result.eligible.length) container.append(element('div', 'No products satisfy these limits. Adjust your budget or quantity to search again.', 'empty'));
  const rejected = $('#rejected'); rejected.replaceChildren(); $('#rejected-count').textContent = `(${result.rejected.length})`;
  for (const p of result.rejected) { const row = element('div', undefined, 'rejected-row'); row.append(element('span', `${p.name} · ${money(p.totalCents)}`), element('span', p.reasons.join(' · '))); rejected.append(row); }
}
function action(label, callback, secondary = false) {
  const button = element('button', label, `payment-button${secondary ? ' secondary' : ''}`);
  button.addEventListener('click', async () => {
    button.disabled = true;
    try { await callback(); } catch (error) { $('#payment-status').textContent = error.message; $('#payment-status').classList.add('error'); }
    finally { button.disabled = false; }
  }); return button;
}
function renderQuote() {
  const q = currentQuote; if (!q) return;
  const expired = q.expiresAt <= Date.now();
  const target = $('#quote'); target.replaceChildren(); target.className = '';
  for (const [label, value] of [['Selected', q.productName], ['Quantity', q.quantity], ['Unit price', money(q.unitCents)], ['Locked total', money(q.totalCents)], ['Expires', new Date(q.expiresAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})]]) {
    const row = element('div', undefined, 'quote-line'); row.append(element('span', label), element('strong', value)); target.append(row);
  }
  target.append(element('div', q.state.replaceAll('_', ' '), 'quote-state'));
  if(q.providerStatus || q.state === 'PAID') target.append(element('div', `PayPal: ${q.state === 'PAID' ? 'COMPLETED' : q.providerStatus.replaceAll('_',' ')}`, 'quote-state'));
  if(q.state === 'PAID') {
    for(const [label,value] of [['Sandbox order',q.orderId],['Verified capture',q.captureId]]) {
      const row=element('div',undefined,'quote-line'); row.append(element('span',label),element('strong',value)); target.append(row);
    }
    $('#runtime').textContent='Completed sandbox capture verified for this quote';
  }
  $('#payment-status').className = '';
  $('#payment-status').textContent = q.state === 'PAID' ? 'Verified completed sandbox capture. No real payment or goods.' : q.state === 'EXPIRED_UNCAPTURED' ? 'Expired local quote closed after PayPal confirmed no capture. The provider order record is retained. Search and select again for a fresh quote.' : q.lastError ? `${q.lastError}. No completed payment has been verified.` : !config.sandboxEnabled ? 'PayPal sandbox is disabled: server credentials are not configured. This quote is local preparation, not PayPal execution.' : 'Sandbox only. You must explicitly approve this exact quote.';
  const actions = $('#payment-actions'); actions.replaceChildren();
  if (!expired && ['QUOTED','CREATING','CREATE_UNKNOWN'].includes(q.state) && config.sandboxEnabled) {
    const label = element('label', undefined, 'consent'); const check = element('input'); check.type = 'checkbox';
    label.append(check, element('span', `I approve this sandbox quote of ${money(q.totalCents)} for ${q.quantity} × ${q.productName}. No real payment.`)); actions.append(label);
    actions.append(action(q.state === 'QUOTED' ? 'Create PayPal sandbox checkout' : 'Retry same sandbox order request', async () => {
      if (!check.checked) throw new Error('Approve the exact quote first.');
      currentQuote = await api(`/api/quotes/${q.id}/create`, { approved: true }); renderQuote();
    }));
  }
  if (!expired && q.state === 'CREATED' && q.approvalUrl) actions.append(action('Open PayPal sandbox for approval ↗', () => { location.assign(q.approvalUrl); }));
  if (!expired && ['CREATED','CAPTURING','CAPTURE_UNKNOWN'].includes(q.state) && config.sandboxEnabled) actions.append(action('Capture approved sandbox order', async () => { currentQuote = await api(`/api/quotes/${q.id}/capture`, { orderId: q.orderId }); renderQuote(); }));
  if (q.orderId && !['PAID','CANCELLED','EXPIRED_UNCAPTURED'].includes(q.state)) actions.append(action('Check payment state · read only', async () => { currentQuote = await api(`/api/quotes/${q.id}/reconcile`, {}); renderQuote(); }, true));
  if (expired && q.orderId && config.sandboxEnabled && !['PAID','CANCELLED','EXPIRED_UNCAPTURED'].includes(q.state)) actions.append(action('Verify expired order is uncaptured & close local quote', async () => { currentQuote = await api(`/api/quotes/${q.id}/expire`, {}); renderQuote(); }, true));
  if (q.state === 'QUOTED') actions.append(action('Release quote', async () => { currentQuote = await api(`/api/quotes/${q.id}/cancel`, {}); renderQuote(); }, true));
}
$('#search-form').addEventListener('submit', async event => {
  event.preventDefault(); if (searching) return; searching = true; $('#search-button').disabled = true;
  const method = $('#method').value;
  status(method === 'semantic' ? 'Running local MiniLM inference from bundled pinned model weights…' : 'Running the TF-IDF keyword baseline. No AI inference in this mode.');
  try {
    const requestedLimits = limits();
    const result = await api('/api/search', { query: $('#query').value, method, ...requestedLimits });
    renderSearch(result, requestedLimits);
    status(`${result.inferenceExecuted ? 'Real MiniLM inference' : 'Keyword baseline · no AI inference'} · ${result.elapsedMs} ms · ${result.notice}`);
  } catch (error) { status(error.message, true); } finally { searching = false; $('#search-button').disabled = false; }
});
for (const control of ['#query','#budget','#quantity','#method']) $(control).addEventListener('input', () => {
  $('#results').replaceChildren(element('div', 'Search again to rank options with your updated request and limits.', 'empty'));
  $('#result-count').textContent = 'Request changed';
});
try {
  config = await api('/api/config');
  $('#runtime').textContent = config.sandboxEnabled ? 'Sandbox configured; actual execution not yet verified' : 'PayPal sandbox disabled · credentials absent';
  const saved = localStorage.getItem('cartguardQuote');
  if (saved) {
    try { currentQuote = await api(`/api/quotes/${saved}`); renderQuote(); }
    catch { localStorage.removeItem('cartguardQuote'); }
  }
  const checkout = new URLSearchParams(location.search).get('checkout');
  if (checkout && currentQuote && currentQuote.state !== 'PAID') $('#payment-status').textContent = checkout === 'cancel' ? 'You returned from PayPal cancellation. No capture was requested here. Check the recorded payment state before retrying.' : 'Returned from sandbox approval. Return alone does not prove payment. Capture the approved order, then verify its amount.';
} catch { status('Local server unavailable. Refresh when the server is running.', true); }
