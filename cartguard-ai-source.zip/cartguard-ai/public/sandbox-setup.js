let config;
const form=document.querySelector('#connect-form'),status=document.querySelector('#connect-status'),button=document.querySelector('#connect-button');
try {
  config=await (await fetch('/api/config')).json();
  if(config.sandboxEnabled){button.disabled=true;status.textContent='Sandbox is already configured in this server process. No credential replacement is allowed here.';}
}catch{button.disabled=true;status.textContent='The local server is unavailable.';}
form.addEventListener('submit',async event=>{
  event.preventDefault();if(button.disabled)return;button.disabled=true;
  const body=JSON.stringify({clientId:document.querySelector('#client-id').value.trim(),clientSecret:document.querySelector('#client-secret').value.trim()});
  form.reset();status.classList.remove('error');status.textContent='Verifying sandbox OAuth. No order is being created…';
  try {
    const response=await fetch('/api/sandbox/connect',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':config.csrf},body});
    const result=await response.json();
    if(!response.ok)throw new Error(result.error??'Connection failed');
    form.hidden=true;status.textContent=`Sandbox OAuth verified at ${result.authVerifiedAt}. Credentials remain only in server memory. Order creation, approval and capture are still unverified. Return to the prototype to test them.`;
  }catch(error){status.textContent=error.message;status.classList.add('error');button.disabled=false;}
});
