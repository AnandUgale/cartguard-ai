import { writeFileSync, mkdirSync, readdirSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { cpus, platform, arch } from 'node:os';
import { search, embed, modelState } from '../src/search.js';
import { dataset } from '../evaluation/queries.js';
import { fileURLToPath } from 'node:url';

const evidence = fileURLToPath(new URL('../evidence/', import.meta.url));
mkdirSync(evidence, { recursive: true });
const warmupStart = performance.now();
const embeddings = await embed(['This is a real model execution check.', 'A headset for clear calls.']);
const warmupMs = performance.now() - warmupStart;
const rows = [];
for (const sample of dataset) {
  const row = { ...sample };
  for (const method of ['keyword','semantic']) {
    const result = await search({ ...sample, method });
    const relevant = new Set(sample.relevant);
    const ranked = result.eligible;
    const dcg = ranked.slice(0,5).reduce((sum,p,i)=>sum+(relevant.has(p.id)?1/Math.log2(i+2):0),0);
    const ideal = sample.relevant.slice(0,5).reduce((sum,_,i)=>sum+1/Math.log2(i+2),0);
    row[method] = {
      top5: ranked.slice(0,5).map(p=>({id:p.id,score:p.score})),
      top1: sample.relevant.length ? Number(relevant.has(ranked[0]?.id)) : Number(ranked.length===0),
      precision3: ranked.slice(0,3).filter(p=>relevant.has(p.id)).length/3,
      recall5: relevant.size ? ranked.slice(0,5).filter(p=>relevant.has(p.id)).length/relevant.size : null,
      ndcg5: ideal ? dcg/ideal : null, elapsedMs:result.elapsedMs,
      violations: ranked.filter(p=>p.totalCents>sample.budgetCents||p.stock<sample.quantity).length,
      noEligible: ranked.length===0
    };
  }
  rows.push(row);
}
const summaries = {};
for(const method of ['keyword','semantic']) {
  const normal=rows.filter(r=>r.relevant.length), noEligible=rows.filter(r=>!r.relevant.length);
  const mean=key=>normal.reduce((sum,row)=>sum+row[method][key],0)/normal.length;
  const latencies=normal.map(r=>r[method].elapsedMs).sort((a,b)=>a-b);
  summaries[method]={positiveQueries:normal.length,top1Accuracy:mean('top1'),precisionAt3:mean('precision3'),recallAt5:mean('recall5'),ndcgAt5:mean('ndcg5'),hardConstraintViolations:rows.reduce((sum,row)=>sum+row[method].violations,0),noEligibleCorrect:noEligible.filter(r=>r[method].noEligible).length,noEligibleCases:noEligible.length,medianWarmQueryMs:latencies[Math.floor(latencies.length/2)]};
}
const cacheRoot=fileURLToPath(new URL('../models/minilm/',import.meta.url));
const hashes=[];
for(const relative of readdirSync(cacheRoot,{recursive:true})) {
  if(typeof relative==='string' && /\.(onnx|json)$/.test(relative) && !relative.includes('/main/') && !relative.includes('\\main\\')) {
    const data=readFileSync(`${cacheRoot}/${relative}`);hashes.push({path:relative.replaceAll('\\','/'),bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});
  }
}
const output={evaluatedAt:new Date().toISOString(),evidenceType:'ACTUAL_LOCAL_AI_EXECUTION; synthetic agent-authored evaluation',humanTesting:false,paypalCalls:0,model:{...modelState},runtime:{node:process.version,platform:platform(),arch:arch(),cpu:cpus()[0]?.model},modelWarmupMs:Math.round(warmupMs),embeddingCheck:{rows:embeddings.length,dimensions:embeddings[0].length,allFinite:embeddings.flat().every(Number.isFinite)},datasetVersion:'CG-synthetic-v1',datasetSha256:createHash('sha256').update(readFileSync(new URL('../evaluation/queries.js',import.meta.url))).digest('hex'),modelFiles:hashes,summaries,rows};
output.runtime.transformers = JSON.parse(readFileSync(new URL('../node_modules/@huggingface/transformers/package.json',import.meta.url),'utf8')).version;
const evidenceVersion = process.argv[2] ?? 'v2';
if (!/^v[0-9]+$/.test(evidenceVersion)) throw new Error('Invalid evidence version');
writeFileSync(`${evidence}/ai-evaluation-${evidenceVersion}.json`,JSON.stringify(output,null,2));
console.log(JSON.stringify({model:output.model,embeddingCheck:output.embeddingCheck,summaries},null,2));
