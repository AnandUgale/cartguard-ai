import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const included=[];
for(const relative of readdirSync(root,{recursive:true})) {
  if(typeof relative!=='string') continue;
  const name=relative.replaceAll('\\','/');
  if(name.startsWith('node_modules/')||name.startsWith('.cache/')||name.startsWith('data/')||name==='.env') continue;
  if(!/\.(js|json|html|css|md)$/.test(name)&&!['LICENSE','.gitignore','.env.example'].includes(name)&&!(name.startsWith('models/')&&/\.(onnx|txt)$/.test(name))) continue;
  const body=readFileSync(`${root}/${relative}`);
  included.push({path:name,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});
}
writeFileSync(new URL('../../evidence/source-manifest-2026-10-25.json',import.meta.url),JSON.stringify({createdAt:new Date().toISOString(),meaning:'Local artifact snapshot, not a Git commit or public submission receipt',files:included.sort((a,b)=>a.path.localeCompare(b.path))},null,2));
console.log(`${included.length} source/config/document files fingerprinted; secrets, cache and local state excluded.`);
