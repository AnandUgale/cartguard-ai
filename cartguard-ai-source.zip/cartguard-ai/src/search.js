import { products, constraints, rejection } from './catalog.js';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

export const modelId = 'Xenova/all-MiniLM-L6-v2';
// Observed on the official model repository's Files and versions page.
export const modelRevision = '751bff37182d3f1213fa05d7196b954e230abad9';
let modelPromise;
let catalogEmbeddings;
export const modelState = { status: 'not_loaded', model: modelId, revision: modelRevision, dtype: 'q8', dimensions: 384 };

export async function embed(texts) {
  if (!modelPromise) {
    modelState.status = 'loading';
    modelPromise = (async () => {
      const { pipeline, env } = await import('@huggingface/transformers');
      const root = new URL('../models/minilm/', import.meta.url);
      const manifest = JSON.parse(readFileSync(new URL('model-manifest.json', root), 'utf8'));
      if (manifest.model !== modelId || manifest.revision !== modelRevision) throw new Error('Bundled model identity mismatch');
      for (const file of manifest.files) {
        if (!['config.json','tokenizer.json','tokenizer_config.json','onnx/model_quantized.onnx'].includes(file.path)) throw new Error('Unexpected model asset');
        const bytes=readFileSync(new URL(file.path,root));
        if(createHash('sha256').update(bytes).digest('hex')!==file.sha256) throw new Error('Bundled model hash mismatch');
      }
      if (manifest.files.length !== 4 || new Set(manifest.files.map(file=>file.path)).size !== 4) throw new Error('Incomplete model assets');
      env.cacheDir = fileURLToPath(new URL('../.cache/', import.meta.url));
      env.allowRemoteModels = false;
      const model = await pipeline('feature-extraction', fileURLToPath(root).replaceAll('\\','/'), { local_files_only:true, dtype: 'q8', device: 'cpu' });
      modelState.artifactSource = 'bundled-pinned-model';
      modelState.status = 'ready';
      return model;
    })().catch(error => { modelState.status = 'error'; modelPromise = undefined; throw error; });
  }
  const extractor = await modelPromise;
  const output = await extractor(texts, { pooling: 'mean', normalize: true });
  const rows = output.tolist();
  if (rows.some(row => row.length !== 384 || row.some(value => !Number.isFinite(value)))) throw new Error('Invalid model output.');
  return rows;
}

const tokens = text => text.toLowerCase().match(/[a-z0-9]+/g) ?? [];
const docs = products.map(p => `${p.name}. ${p.description}`);
const docTokens = docs.map(tokens);
const vocabulary = [...new Set(docTokens.flat())];
const idf = new Map(vocabulary.map(t => [t, Math.log((1 + products.length) / (1 + docTokens.filter(d => d.includes(t)).length)) + 1]));
const vector = text => {
  const terms = tokens(text);
  return vocabulary.map(t => terms.filter(w => w === t).length * idf.get(t));
};
const cosine = (a, b) => {
  const dot = a.reduce((sum, v, i) => sum + v * b[i], 0);
  const norm = Math.sqrt(a.reduce((sum, v) => sum + v * v, 0) * b.reduce((sum, v) => sum + v * v, 0));
  return norm ? dot / norm : 0;
};
const baselineVectors = docs.map(vector);

export async function search({ query, budgetCents, quantity, method = 'semantic' }) {
  constraints(budgetCents, quantity);
  if (typeof query !== 'string' || query.trim().length < 3 || query.length > 400) throw new Error('Describe your need in 3–400 characters.');
  if (!['semantic', 'keyword'].includes(method)) throw new Error('Unknown search method.');
  const start = performance.now();
  let scores;
  if (method === 'semantic') {
    if (!catalogEmbeddings) catalogEmbeddings = embed(docs).catch(e => { catalogEmbeddings = undefined; throw e; });
    const embeddings = await catalogEmbeddings;
    const [queryEmbedding] = await embed([query]);
    scores = embeddings.map(row => cosine(queryEmbedding, row));
  } else {
    const q = vector(query);
    scores = baselineVectors.map(row => cosine(q, row));
  }
  const ranked = products.map((p, i) => ({ ...p, totalCents: p.priceCents * quantity, score: scores[i], reasons: rejection(p, budgetCents, quantity) }))
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
  return {
    method, inferenceExecuted: method === 'semantic', model: method === 'semantic' ? { ...modelState } : null,
    elapsedMs: Math.round(performance.now() - start),
    eligible: ranked.filter(p => p.reasons.length === 0), rejected: ranked.filter(p => p.reasons.length > 0),
    // Ranking is not a confidence/probability of suitability. No automatic purchase.
    notice: 'Relative relevance ranking only. Review catalog attributes before selecting. Synthetic merchant inventory.'
  };
}
