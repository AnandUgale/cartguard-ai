import http from 'node:http';
import { readFileSync, mkdirSync } from 'node:fs';
import { randomUUID, randomBytes, createHmac } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { Commerce, CommerceError } from './commerce.js';
import { PayPalSandbox } from './paypal.js';
import { search, modelState } from './search.js';
import { connectSandbox } from './sandbox-connection.js';

const port = Number(process.env.PORT || 8765);
const origin = `http://127.0.0.1:${port}`;
const dataDir = fileURLToPath(new URL('../data/', import.meta.url));
mkdirSync(dataDir, { recursive: true });
const payment = new PayPalSandbox({ clientId: process.env.PAYPAL_CLIENT_ID, clientSecret: process.env.PAYPAL_CLIENT_SECRET, origin });
const commerce = new Commerce({ path: `${dataDir}/cartguard.sqlite`, payment });
const csrfSecret = randomBytes(32);
let connectionOwner = null;
let connectionInProgress = false;
const csrf = owner => createHmac('sha256', csrfSecret).update(owner).digest('hex');
const assets = new Map([
  ['/', ['../public/index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['../public/app.js', 'text/javascript; charset=utf-8']],
  ['/style.css', ['../public/style.css', 'text/css; charset=utf-8']]
  ,['/sandbox-setup', ['../public/sandbox-setup.html', 'text/html; charset=utf-8']]
  ,['/sandbox-setup.js', ['../public/sandbox-setup.js', 'text/javascript; charset=utf-8']]
].map(([url, [file, type]]) => [url, { body: readFileSync(new URL(file, import.meta.url)), type }]));

async function jsonBody(req) {
  if (req.headers['content-type'] !== 'application/json') throw new CommerceError('JSON_REQUIRED', 415);
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body) > 8192) throw new CommerceError('REQUEST_TOO_LARGE', 413);
  }
  try { const parsed = JSON.parse(body); if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error(); return parsed; }
  catch { throw new CommerceError('INVALID_JSON', 400); }
}

export const server = http.createServer(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
  const reply = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
  try {
    if (req.headers.host !== `127.0.0.1:${port}`) throw new CommerceError('INVALID_HOST', 403);
    const url = new URL(req.url, origin);
    let owner = req.headers.cookie?.match(/(?:^|;\s*)cartguard=([a-f0-9-]{36})(?:;|$)/)?.[1];
    // PayPal returns by a top-level cross-site GET. Lax retains this session
    // there, while every mutation still requires our exact Origin and HMAC CSRF.
    if (!owner) owner = randomUUID();
    res.setHeader('Set-Cookie', `cartguard=${owner}; HttpOnly; SameSite=Lax; Path=/`);
    if (req.method === 'GET' && assets.has(url.pathname)) {
      const asset = assets.get(url.pathname); res.writeHead(200, { 'Content-Type': asset.type }); res.end(asset.body); return;
    }
    if (req.method === 'GET' && url.pathname === '/api/config') return reply(200, { csrf: csrf(owner), sandboxEnabled: payment.enabled, sandboxAuthVerifiedAt: payment.authVerifiedAt ?? null, paymentMode: payment.mode, model: modelState });
    if (url.pathname === '/api/sandbox/evidence' && req.method === 'GET') {
      if (connectionOwner && connectionOwner !== owner) throw new CommerceError('SANDBOX_SESSION_MISMATCH',403);
      return reply(200, { sandbox: true, authVerifiedAt: payment.authVerifiedAt ?? null, events: payment.events });
    }
    const route = url.pathname.match(/^\/api\/quotes\/([a-f0-9-]{36})(?:\/(create|capture|reconcile|cancel|expire))?$/);
    if (req.method === 'GET' && route && !route[2]) return reply(200, commerce.public(commerce.read(route[1], owner)));
    if (req.method !== 'POST') throw new CommerceError('NOT_FOUND', 404);
    if (req.headers.origin !== origin || req.headers['x-csrf-token'] !== csrf(owner)) throw new CommerceError('REQUEST_NOT_AUTHORIZED', 403);
    const body = await jsonBody(req);
    if (url.pathname === '/api/sandbox/connect') {
      if (connectionInProgress) throw new CommerceError('SANDBOX_CONNECTION_IN_PROGRESS',409);
      connectionInProgress = true;
      try {
        const result = await connectSandbox(payment,body,origin);
        connectionOwner = owner;
        return reply(200,result);
      } finally { connectionInProgress = false; }
    }
    if (url.pathname === '/api/search') {
      try { return reply(200, await search(body)); } catch (error) {
        if (modelState.status === 'error') throw new CommerceError('MODEL_UNAVAILABLE_NO_AI_FALLBACK', 503);
        throw new CommerceError(error.message, 400);
      }
    }
    if (url.pathname === '/api/quotes') return reply(201, commerce.quote(owner, body));
    if (route) {
      const [_, id, action] = route;
      if (connectionOwner && connectionOwner !== owner && ['create','capture','reconcile','expire'].includes(action)) throw new CommerceError('SANDBOX_SESSION_MISMATCH',403);
      if (action === 'create') return reply(200, await commerce.create(id, owner, body.approved));
      if (action === 'capture') return reply(200, await commerce.capture(id, owner, body.orderId));
      if (action === 'reconcile') return reply(200, await commerce.reconcile(id, owner));
      if (action === 'expire') return reply(200, await commerce.expireUncaptured(id, owner));
      if (action === 'cancel') return reply(200, await commerce.cancel(id, owner));
    }
    throw new CommerceError('NOT_FOUND', 404);
  } catch (error) {
    reply(error.status ?? 400, { error: error.code ?? 'INVALID_REQUEST' });
  }
});
server.requestTimeout = 30000;
server.listen(port, '127.0.0.1', () => console.log(`CartGuard local prototype: ${origin} | sandbox ${payment.enabled ? 'configured, not yet tested' : 'disabled: credentials absent'}`));
