import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { products, catalogVersion, constraints, rejection } from './catalog.js';
import { verifyCapture } from './paypal.js';

export class CommerceError extends Error {
  constructor(code, status = 409) { super(code); this.code = code; this.status = status; }
}
export class Commerce {
  constructor({ path = ':memory:', payment, now = () => Date.now() } = {}) {
    this.db = new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=3000;
      CREATE TABLE IF NOT EXISTS quotes (id TEXT PRIMARY KEY, owner TEXT NOT NULL, body TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS payment_claims (quote_id TEXT PRIMARY KEY, token TEXT NOT NULL, lease_until INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS payment_ops (
        quote_id TEXT NOT NULL, kind TEXT NOT NULL, request_id TEXT NOT NULL UNIQUE,
        state TEXT NOT NULL, order_id TEXT, capture_id TEXT, amount_cents INTEGER NOT NULL,
        currency TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
        last_reconciled_at INTEGER, PRIMARY KEY(quote_id,kind));
      CREATE UNIQUE INDEX IF NOT EXISTS one_create_per_provider_order ON payment_ops(order_id) WHERE kind='create' AND order_id IS NOT NULL;
      CREATE UNIQUE INDEX IF NOT EXISTS one_capture_identity ON payment_ops(capture_id) WHERE capture_id IS NOT NULL;`);
    this.payment = payment;
    this.now = now;
    this.locks = new Map();
    this.activeClaims = new Map();
  }
  close() { this.db.close(); }
  read(id, owner) {
    const row = this.db.prepare('SELECT body FROM quotes WHERE id=? AND owner=?').get(id, owner);
    if (!row) throw new CommerceError('QUOTE_NOT_FOUND', 404);
    return JSON.parse(row.body);
  }
  save(q) {
    return this.transaction(() => {
      const token = this.activeClaims.get(q.id);
      if (token && this.db.prepare('SELECT token FROM payment_claims WHERE quote_id=?').get(q.id)?.token !== token) throw new CommerceError('PAYMENT_CLAIM_LOST');
      // Quote outcome and unique provider identities are committed atomically.
      // Old local preparation databases are backfilled here without new keys.
      this.ensureOperations(q);
      const stamp = this.now();
      const createState = q.orderId ? 'CONFIRMED' : q.state;
      this.db.prepare('UPDATE payment_ops SET state=?,order_id=?,updated_at=? WHERE quote_id=? AND kind=?').run(createState, q.orderId, stamp, q.id, 'create');
      this.db.prepare('UPDATE payment_ops SET state=?,order_id=?,capture_id=?,updated_at=?,last_reconciled_at=? WHERE quote_id=? AND kind=?').run(q.state, q.orderId, q.captureId, stamp, q.lastReconciledAt ?? null, q.id, 'capture');
      this.db.prepare('UPDATE quotes SET body=? WHERE id=?').run(JSON.stringify(q), q.id);
      return q;
    });
  }
  ensureOperations(q) {
    for (const kind of ['create','capture']) this.db.prepare('INSERT OR IGNORE INTO payment_ops (quote_id,kind,request_id,state,amount_cents,currency,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(q.id, kind, kind === 'create' ? q.createRequestId : q.captureRequestId, 'PREPARED', q.totalCents, q.currency, q.createdAt, this.now());
  }
  public(q) {
    const { owner, createRequestId, captureRequestId, ...safe } = q;
    return { ...safe, sandbox: true, synthetic: true, paymentMode: this.payment.mode, fulfillment: 'No real goods or fulfillment' };
  }
  transaction(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const result = fn(); this.db.exec('COMMIT'); return result; } catch (error) { this.db.exec('ROLLBACK'); throw error; }
  }
  quote(owner, body) {
    return this.transaction(() => {
      if (Object.keys(body).some(key => !['productId', 'quantity', 'budgetCents'].includes(key))) throw new CommerceError('UNEXPECTED_QUOTE_FIELDS', 400);
      constraints(body.budgetCents, body.quantity);
      const p = products.find(p => p.id === body.productId);
      if (!p || rejection(p, body.budgetCents, body.quantity).length) throw new CommerceError('PRODUCT_INELIGIBLE');
      const reserved = this.db.prepare('SELECT body FROM quotes').all().map(row => JSON.parse(row.body))
        .filter(q => q.productId === p.id && (['PAID', 'REVIEW', 'CREATE_UNKNOWN', 'CAPTURE_UNKNOWN', 'CREATING', 'CAPTURING'].includes(q.state) || (['QUOTED', 'CREATED'].includes(q.state) && q.expiresAt > this.now())))
        .reduce((sum, q) => sum + q.quantity, 0);
      if (reserved + body.quantity > p.stock) throw new CommerceError('STOCK_CHANGED');
      const q = { id: randomUUID(), owner, productId: p.id, productName: p.name, unitCents: p.priceCents,
        quantity: body.quantity, budgetCents: body.budgetCents, totalCents: p.priceCents * body.quantity,
        currency: 'USD', catalogVersion, createdAt: this.now(), expiresAt: this.now() + 10 * 60 * 1000,
        state: 'QUOTED', createRequestId: randomUUID(), captureRequestId: randomUUID(), orderId: null, captureId: null,
        approvedAt: null, lastError: null, approvalUrl: null };
      this.db.prepare('INSERT INTO quotes VALUES (?,?,?)').run(q.id, owner, JSON.stringify(q));
      this.ensureOperations(q);
      return this.public(q);
    });
  }
  async locked(id, fn) {
    const previous = this.locks.get(id) ?? Promise.resolve();
    let release;
    const current = new Promise(resolve => { release = resolve; });
    this.locks.set(id, current);
    await previous;
    let token;
    try {
      token = this.transaction(() => {
        if (!this.db.prepare('SELECT id FROM quotes WHERE id=?').get(id)) throw new CommerceError('QUOTE_NOT_FOUND', 404);
        const claim = this.db.prepare('SELECT lease_until FROM payment_claims WHERE quote_id=?').get(id);
        if (claim && claim.lease_until > this.now()) throw new CommerceError('PAYMENT_OPERATION_IN_PROGRESS');
        const next = randomUUID();
        // Each provider request has a 15-second timeout; a normal OAuth,
        // capture and status-read chain stays below this 90-second lease.
        this.db.prepare('INSERT INTO payment_claims VALUES (?,?,?) ON CONFLICT(quote_id) DO UPDATE SET token=excluded.token,lease_until=excluded.lease_until').run(id, next, this.now() + 90000);
        return next;
      });
      this.activeClaims.set(id, token);
      return await fn();
    } finally {
      if (token) { this.activeClaims.delete(id); this.db.prepare('DELETE FROM payment_claims WHERE quote_id=? AND token=?').run(id, token); }
      release(); if (this.locks.get(id) === current) this.locks.delete(id);
    }
  }
  unexpired(q) { if (q.expiresAt <= this.now()) throw new CommerceError('QUOTE_EXPIRED'); }
  configured() { if (!this.payment.enabled) throw new CommerceError('SANDBOX_NOT_CONFIGURED', 503); }
  async create(id, owner, approval) {
    return this.locked(id, async () => {
      const q = this.read(id, owner);
      if (['CREATED', 'PAID', 'CAPTURE_UNKNOWN'].includes(q.state)) return this.public(q);
      this.configured(); this.unexpired(q);
      if (approval !== true) throw new CommerceError('EXPLICIT_APPROVAL_REQUIRED', 400);
      if (!['QUOTED', 'CREATING', 'CREATE_UNKNOWN'].includes(q.state)) throw new CommerceError('INVALID_STATE');
      q.approvedAt ??= this.now(); q.state = 'CREATING'; q.lastError = null; this.save(q);
      try {
        const order = await this.payment.create(q);
        if (!/^[A-Z0-9]{5,40}$/.test(order.id ?? '')) throw new Error('Invalid order response');
        const url = order.links?.find(link => ['payer-action', 'approve'].includes(link.rel))?.href;
        // Never redirect a shopper to live PayPal or arbitrary upstream links.
        const parsed = new URL(url);
        if (parsed.protocol !== 'https:' || parsed.hostname !== 'www.sandbox.paypal.com' || parsed.username || parsed.password) throw new Error('Invalid approval URL');
        q.orderId = order.id; q.approvalUrl = parsed.href; q.state = 'CREATED';
      } catch (error) {
        q.state = 'CREATE_UNKNOWN'; q.lastError = error.code ?? 'CREATE_OUTCOME_UNKNOWN';
      }
      return this.public(this.save(q));
    });
  }
  record(q, order) {
    if (verifyCapture(order, q)) {
      q.state = 'PAID'; q.captureId = order.purchase_units[0].payments.captures[0].id; q.lastError = null;
    } else if (order.status === 'COMPLETED') { q.state = 'REVIEW'; q.lastError = 'CAPTURE_VERIFICATION_MISMATCH'; }
    else { q.state = 'CAPTURE_UNKNOWN'; q.lastError = 'CAPTURE_NOT_CONFIRMED'; }
    return this.public(this.save(q));
  }
  async capture(id, owner, orderId) {
    return this.locked(id, async () => {
      const q = this.read(id, owner);
      if (!q.orderId || orderId !== q.orderId) throw new CommerceError('ORDER_MISMATCH');
      if (q.state === 'PAID') return this.public(q);
      this.configured(); this.unexpired(q);
      if (!['CREATED', 'CAPTURING', 'CAPTURE_UNKNOWN'].includes(q.state)) throw new CommerceError('INVALID_STATE');
      // Recovery after a lost reply is read-only first; never create a new order.
      if (['CAPTURING', 'CAPTURE_UNKNOWN'].includes(q.state)) {
        const recovered = await this.payment.get(q).catch(() => null);
        if (!recovered) return this.public(q);
        if (recovered.status === 'COMPLETED') return this.record(q, recovered);
        if (recovered.id !== q.orderId || recovered.status !== 'APPROVED') return this.public(q);
      }
      q.state = 'CAPTURING'; q.lastError = null; this.save(q);
      try {
        await this.payment.capture(q);
        // Capture responses can omit order fields. Verify the full bound order,
        // fetched server-side, before marking it paid.
        return this.record(q, await this.payment.get(q));
      }
      catch (error) { q.state = 'CAPTURE_UNKNOWN'; q.lastError = error.code ?? 'CAPTURE_OUTCOME_UNKNOWN'; return this.public(this.save(q)); }
    });
  }
  async reconcile(id, owner) {
    return this.locked(id, async () => {
      const q = this.read(id, owner);
      if (q.state === 'PAID') return this.public(q);
      if (!q.orderId || q.state === 'CANCELLED') throw new CommerceError('NOT_RECONCILABLE');
      this.configured();
      try {
        const order = await this.payment.get(q);
        q.lastReconciledAt = this.now();
        if (['CREATED','SAVED','APPROVED','VOIDED','COMPLETED','PAYER_ACTION_REQUIRED'].includes(order.status)) q.providerStatus = order.status;
        if (order.id !== q.orderId) { q.state = 'REVIEW'; q.lastError = 'ORDER_MISMATCH'; return this.public(this.save(q)); }
        if (order.status === 'COMPLETED') return this.record(q, order);
        q.lastError = 'NO_COMPLETED_CAPTURE';
        // Read-only recovery remains available after quote expiry; capture does not.
        return this.public(this.save(q));
      } catch { q.lastError = 'RECONCILIATION_UNAVAILABLE'; return this.public(this.save(q)); }
    });
  }
  async expireUncaptured(id, owner) {
    return this.locked(id, async () => {
      const q = this.read(id, owner);
      if (['PAID','EXPIRED_UNCAPTURED'].includes(q.state)) return this.public(q);
      if (q.expiresAt > this.now()) throw new CommerceError('QUOTE_NOT_EXPIRED');
      if (!q.orderId) throw new CommerceError('NO_BOUND_ORDER_TO_VERIFY');
      this.configured();
      const order = await this.payment.get(q); // A transport failure never releases stock.
      if (order.id !== q.orderId) throw new CommerceError('ORDER_MISMATCH');
      if (order.status === 'COMPLETED') return this.record(q, order);
      if (!['CREATED','SAVED','PAYER_ACTION_REQUIRED','VOIDED'].includes(order.status)) throw new CommerceError('ORDER_NOT_SAFE_TO_EXPIRE');
      if (!Array.isArray(order.purchase_units) || order.purchase_units.length !== 1 ||
          order.purchase_units.some(unit => (unit.payments?.captures?.length ?? 0) > 0 || (unit.payments?.authorizations?.length ?? 0) > 0)) throw new CommerceError('PAYMENT_ACTIVITY_NEEDS_REVIEW');
      q.state = 'EXPIRED_UNCAPTURED'; q.providerStatus = order.status;
      q.lastReconciledAt = this.now(); q.lastError = 'EXPIRED_ORDER_VERIFIED_UNCAPTURED';
      // Terms and provider record remain immutable. This ends only the local
      // quote; it does not claim to cancel the provider's pending order.
      return this.public(this.save(q));
    });
  }
  async cancel(id, owner) {
    return this.locked(id, async () => {
      const q = this.read(id, owner);
      if (q.state !== 'QUOTED') throw new CommerceError('RECONCILE_BEFORE_CANCELLATION');
      q.state = 'CANCELLED'; return this.public(this.save(q));
    });
  }
}
