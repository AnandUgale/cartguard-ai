import { dollars } from './catalog.js';

export const SANDBOX = 'https://api-m.sandbox.paypal.com';
export class PaymentError extends Error {
  constructor(code, uncertain = false) { super(code); this.code = code; this.uncertain = uncertain; }
}
export class PayPalSandbox {
  constructor({ clientId, clientSecret, fetchImpl = fetch, origin = 'http://127.0.0.1:8765' } = {}) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.fetch = fetchImpl;
    this.origin = origin;
    this.enabled = Boolean(clientId && clientSecret);
    this.mode = 'paypal-sandbox';
    this.events = [];
  }
  async token() {
    if (!this.enabled) throw new PaymentError('SANDBOX_NOT_CONFIGURED');
    if (this.accessToken && this.expires > Date.now()) return this.accessToken;
    let response;
    try {
      response = await this.fetch(`${SANDBOX}/v1/oauth2/token`, {
        method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'grant_type=client_credentials', signal: AbortSignal.timeout(15000), redirect: 'error'
      });
      this.events.push({at:new Date().toISOString(),method:'POST',path:'/v1/oauth2/token',status:response.status ?? null});
      if (!response.ok) throw new PaymentError('SANDBOX_AUTH_FAILED');
      const data = await response.json();
      if (!data.access_token) throw new PaymentError('SANDBOX_AUTH_FAILED');
      this.accessToken = data.access_token;
      this.expires = Date.now() + Math.max(0, Number(data.expires_in ?? 60) - 30) * 1000;
      return this.accessToken;
    } catch { throw new PaymentError('SANDBOX_AUTH_FAILED'); }
  }
  async request(path, method = 'GET', body, requestId) {
    const token = await this.token();
    try {
      const response = await this.fetch(`${SANDBOX}${path}`, {
        method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'return=representation', ...(requestId ? { 'PayPal-Request-Id': requestId } : {}) },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(15000), redirect: 'error'
      });
      const event = {at:new Date().toISOString(),method,path,status:response.status ?? null};
      this.events.push(event);
      if (!response.ok) {
        if (response.status === 401) this.expires = 0;
        // Whitelist machine issue codes only. Never preserve raw error bodies,
        // descriptions, headers, tokens, payer data, or arbitrary messages.
        const failure = await response.json?.().catch(() => ({})) ?? {};
        const issue = failure.details?.map(detail => detail.issue).find(value => typeof value === 'string' && /^[A-Z0-9_]{1,64}$/.test(value));
        if (issue) event.issue = issue;
        throw new PaymentError(issue ? `SANDBOX_${issue}` : `SANDBOX_HTTP_${response.status}`, response.status >= 500 || response.status === 429);
      }
      const data = await response.json();
      if (/^\/v2\/checkout\/orders\/[A-Z0-9]+$/.test(path) && method === 'GET' && ['CREATED','SAVED','APPROVED','VOIDED','COMPLETED','PAYER_ACTION_REQUIRED'].includes(data.status)) event.orderStatus = data.status;
      return data;
    } catch (error) {
      if (error instanceof PaymentError) throw error;
      throw new PaymentError('SANDBOX_OUTCOME_UNKNOWN', true);
    }
  }
  create(quote) {
    return this.request('/v2/checkout/orders', 'POST', {
      intent: 'CAPTURE', purchase_units: [{ reference_id: quote.id, custom_id: quote.id,
        amount: { currency_code: 'USD', value: dollars(quote.totalCents) },
        description: 'CartGuard fictional catalog — sandbox demonstration only'
      }], payment_source: { paypal: { experience_context: {
        brand_name: 'CartGuard Sandbox', user_action: 'PAY_NOW', shipping_preference: 'NO_SHIPPING',
        return_url: `${this.origin}/?checkout=return`, cancel_url: `${this.origin}/?checkout=cancel`
      } } }
    }, quote.createRequestId);
  }
  capture(quote) {
    return this.request(`/v2/checkout/orders/${encodeURIComponent(quote.orderId)}/capture`, 'POST', {}, quote.captureRequestId);
  }
  get(quote) { return this.request(`/v2/checkout/orders/${encodeURIComponent(quote.orderId)}`); }
}

export function verifyCapture(order, quote) {
  if (order.id !== quote.orderId || order.intent !== 'CAPTURE' || order.status !== 'COMPLETED') return false;
  if (order.purchase_units?.length !== 1) return false;
  const unit = order.purchase_units[0];
  if (unit.reference_id !== quote.id || unit.custom_id !== quote.id) return false;
  if (unit.amount?.currency_code !== quote.currency || unit.amount?.value !== dollars(quote.totalCents)) return false;
  const captures = unit.payments?.captures;
  if (captures?.length !== 1) return false;
  const capture = captures[0];
  return Boolean(capture.id && capture.status === 'COMPLETED' && capture.final_capture === true &&
    capture.amount?.currency_code === quote.currency && capture.amount?.value === dollars(quote.totalCents) &&
    (!capture.supplementary_data?.related_ids?.order_id || capture.supplementary_data.related_ids.order_id === quote.orderId));
}
