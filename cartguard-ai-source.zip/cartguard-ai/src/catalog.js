// Original, fictional inventory for one demonstration merchant. No goods are sold.
export const catalogVersion = 'synthetic-2026-10-25-v1';
export const products = [
  ['call-comfort', 'CallComfort H2', 'Over-ear USB headset with padded ear cups and a noise-reducing boom microphone for long video meetings.', 6900, 8, 'audio', '🎧'],
  ['studio-max', 'StudioMax X', 'Premium wireless over-ear headphones for studio music monitoring, immersive sound and active noise cancellation.', 10900, 5, 'audio', '🎧'],
  ['pocket-buds', 'PocketBuds', 'Compact wireless earbuds for listening to songs on a commute, charging case included.', 3900, 12, 'audio', '🎵'],
  ['desk-mic', 'DeskVoice', 'USB desktop microphone for clear speech on podcasts, online classes and video conferencing.', 4900, 7, 'audio', '🎙️'],
  ['open-ear', 'OpenAir Clip', 'Lightweight open-ear headphones for outdoor jogging while hearing surrounding traffic.', 5900, 0, 'audio', '🏃'],
  ['conference', 'TeamCircle', 'USB speakerphone with omnidirectional microphone for a small meeting room.', 7900, 3, 'audio', '🔊'],
  ['quiet-keys', 'SoftType', 'Low-noise full-size keyboard for typing in shared offices without disturbing colleagues.', 4500, 9, 'workspace', '⌨️'],
  ['split-keys', 'SplitFlow', 'Ergonomic split keyboard with wrist support for a relaxed typing posture.', 8900, 4, 'workspace', '⌨️'],
  ['travel-keys', 'FoldType', 'Folding Bluetooth keyboard that packs into a small bag for travel.', 3500, 6, 'workspace', '⌨️'],
  ['vertical-mouse', 'Upright Mouse', 'Vertical wireless mouse designed for a natural wrist position during desk work.', 3200, 10, 'workspace', '🖱️'],
  ['precision-mouse', 'Pixel Mouse', 'Wired high precision mouse with programmable controls for fast gaming.', 2900, 11, 'workspace', '🖱️'],
  ['track-pad', 'TouchSlate', 'Large multi-touch trackpad with gesture controls for navigating documents.', 6500, 5, 'workspace', '▧'],
  ['monitor-stand', 'ScreenRise', 'Adjustable monitor riser that raises the display to eye level and frees desk storage.', 2800, 8, 'workspace', '🖥️'],
  ['laptop-stand', 'LiftBook', 'Foldable aluminum laptop stand to elevate a notebook screen and improve desk posture.', 3600, 10, 'workspace', '💻'],
  ['desk-lamp', 'FocusGlow', 'Dimmable LED desk lamp with adjustable color temperature for reading and evening study.', 2400, 13, 'workspace', '💡'],
  ['webcam', 'ClearFrame', '1080p USB webcam with privacy shutter for sharp video meetings and remote lessons.', 5400, 6, 'workspace', '📷'],
  ['power-bank', 'DayCharge', 'Portable 20000 mAh battery with USB-C charging for keeping a phone powered on long trips.', 4200, 10, 'travel', '🔋'],
  ['wall-charger', 'QuickPlug', 'Compact 65 watt USB-C wall charger for powering a laptop and phone at a desk or hotel.', 3800, 8, 'travel', '🔌'],
  ['usb-hub', 'PortBridge', 'USB-C hub with HDMI, USB-A and card reader for connecting a laptop to displays and accessories.', 4600, 7, 'travel', '🔗'],
  ['cable-kit', 'CableRoll', 'Three short charging cables in a zipped pouch for organizing travel electronics.', 1500, 20, 'travel', '🧵'],
  ['day-pack', 'CityCarry', 'Water-resistant lightweight backpack with padded laptop sleeve for daily commuting.', 5800, 9, 'travel', '🎒'],
  ['sling', 'PocketTrail', 'Small cross-body sling bag for carrying wallet, phone and keys while walking.', 2200, 12, 'travel', '👜'],
  ['flask', 'WarmSip', 'Insulated stainless steel bottle that keeps coffee warm during a long train journey.', 2600, 15, 'travel', '☕'],
  ['rain-cover', 'RainShell', 'Packable waterproof rain cover to protect a backpack during wet weather.', 1400, 17, 'travel', '☔'],
  ['reader', 'PageLight', 'Small rechargeable clip-on book light for reading in bed without lighting the room.', 1800, 16, 'home', '📖'],
  ['timer', 'FocusTimer', 'Visual countdown timer for focused study sessions with optional silent alerts.', 2100, 9, 'home', '⏳'],
  ['speaker', 'RoomTune', 'Portable Bluetooth speaker for playing music at a picnic with friends.', 4800, 8, 'audio', '🔊'],
  ['sound-machine', 'SleepWave', 'Bedside white noise machine with ocean and rain sounds for restful sleep.', 3300, 6, 'home', '🌙'],
  ['notebook', 'DotJournal', 'Dotted paper notebook for handwritten planning, sketching and tracking daily tasks.', 1200, 25, 'home', '📓'],
  ['drawing-pad', 'SketchPad', 'USB drawing tablet with pressure-sensitive stylus for digital illustration.', 7400, 4, 'workspace', '✍️']
].map(([id, name, description, priceCents, stock, category, icon]) => Object.freeze({ id, name, description, priceCents, stock, category, icon, currency: 'USD', synthetic: true }));

export function constraints(budgetCents, quantity) {
  if (!Number.isSafeInteger(budgetCents) || budgetCents < 1 || budgetCents > 1000000) throw new Error('Budget must be integer cents from 1 to 1000000.');
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) throw new Error('Quantity must be a whole number from 1 to 20.');
}
export function rejection(product, budgetCents, quantity) {
  const reasons = [];
  if (product.stock < quantity) reasons.push(product.stock === 0 ? 'Out of stock' : `Only ${product.stock} available`);
  if (product.priceCents * quantity > budgetCents) reasons.push('Total exceeds budget');
  return reasons;
}
export const dollars = cents => (cents / 100).toFixed(2);
