import { PayPalSandbox } from './paypal.js';

export class ConnectionError extends Error {
  constructor(code, status = 400) { super(code); this.code = code; this.status = status; }
}
// The form sends credentials to this loopback server only. They are never
// returned in API responses, persisted to disk, or included in evidence.
export async function connectSandbox(payment, body, origin, factory = options => new PayPalSandbox(options)) {
  if (payment.enabled) throw new ConnectionError('SANDBOX_ALREADY_CONFIGURED', 409);
  if (Object.keys(body).some(key => !['clientId', 'clientSecret'].includes(key))) throw new ConnectionError('UNEXPECTED_CREDENTIAL_FIELDS');
  if (![body.clientId,body.clientSecret].every(value => typeof value === 'string' && /^[\x21-\x7e]{16,512}$/.test(value))) throw new ConnectionError('INVALID_SANDBOX_CREDENTIAL_FORMAT');
  const candidate = factory({ clientId: body.clientId, clientSecret: body.clientSecret, origin });
  // Successful OAuth establishes access, not successful Orders integration.
  await candidate.token();
  Object.assign(payment, candidate);
  payment.authVerifiedAt = new Date().toISOString();
  return { connected: true, sandbox: true, storage: 'server-memory-only', authVerifiedAt: payment.authVerifiedAt, orderCaptureVerified: false };
}
